// #include <iostream>

// using std::cin;
// using std::cout;
// using std::endl;

// int main() {
//   int x;
//   int y;
//   cout << "please enter x: ";
//   cin >> x;
//   cout << endl <<"please enter y: ";
//   cin >> y;
//   x = x * x;
//   y = y * y;
//   cout << endl << "x^2 = " << x << endl << "y^2 = " << y << endl;

// }



// // Завдання 2
// // Напишіть програму, яка запитує два цілих числа x і y, після чого
// // обчислює і виводить значення x у степені y.
// // Завдання 3
// // Знайти середнє арифметичне всіх цілих чисел від 1 до 1000