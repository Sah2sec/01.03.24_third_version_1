// #include <iostream>

// using std::cin;
// using std::cout;
// using std::endl;

// int main() {
//   int a;
//   int sum = 0;
//   cout << "enter a number under 500: ";
//   cin >> a;

//   if (a < 500) {
//     for (int i = a; i <= 500; i++) {
//       sum += i;
//     }
//     cout << "the sum of all the numbers between " << a << " and 50 is " << sum << endl;
//   }
//   else {
//     cout << "do you stupid or what?";
//   }

// }

// // Напишіть програму, яка обчислює суму цілих чисел від а до 500
// // (значення a вводиться з клавіатури).
