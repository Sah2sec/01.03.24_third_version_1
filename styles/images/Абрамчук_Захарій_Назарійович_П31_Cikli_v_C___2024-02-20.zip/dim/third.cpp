// #include <iostream>

// using std::cin;
// using std::cout;
// using std::endl;

// int main() {
//   int sum = 0;
//   int result = 0;
//   for (int i = 0; i < 1001; i++) {
//     sum += i;
//   }
//   result = sum / 1000;
//   cout << "the arithmetic mean of the sum of numbers from 0 to 1000 is: " << result << endl;
// }



// // Завдання 3
// // Знайти середнє арифметичне всіх цілих чисел від 1 до 1000